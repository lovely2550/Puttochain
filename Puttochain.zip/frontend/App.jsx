import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

export default function App() {
  const [username, setUsername] = useState("");
  const [journals, setJournals] = useState([]);
  const [karma, setKarma] = useState(0);
  const [entry, setEntry] = useState("");

  const addJournal = async () => {
    await fetch("http://localhost:8000/journals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, entry, karma: 10 }),
    });
    fetchJournals();
  };

  const fetchJournals = async () => {
    const res = await fetch(`http://localhost:8000/journals/${username}`);
    const data = await res.json();
    setJournals(data);
    const karmaRes = await fetch(`http://localhost:8000/karma/${username}`);
    setKarma(await karmaRes.json());
  };

  return (
    <div className="p-6 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold">Buddhochain Dashboard</h1>

      <input
        className="border p-2 rounded w-full my-2"
        placeholder="Your username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />

      <textarea
        className="border p-2 rounded w-full my-2"
        placeholder="Meditation log..."
        value={entry}
        onChange={(e) => setEntry(e.target.value)}
      />

      <Button onClick={addJournal}>Add Journal +10 Karma</Button>

      <h2 className="text-xl mt-4">Your Karma: {karma}</h2>

      <ul className="mt-2">
        {journals.map((j, i) => (
          <li key={i} className="p-2 border-b">
            {j.entry} — +{j.karma} karma
          </li>
        ))}
      </ul>
    </div>
  );
}
