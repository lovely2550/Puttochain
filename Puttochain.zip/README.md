# 🪷 Buddhochain (พุทธโธเชน)

**Digital Dhammachakra — Blockchain + AI + Dhamma**

Buddhochain (Puttochain) integrates:
- 🪙 Karma Token (ERC-20 on Polygon)
- 📜 DAO for ethical decision-making
- 📖 Meditation Journal & Karma Log
- 🤖 AI Coach (Somdej Ong Pathom style)
- 🌐 React Dashboard

---

## 📂 Structure
- smart-contracts/ — Solidity (Karma Token + DAO)
- backend/ — FastAPI (Auth, Journals, Karma Engine)
- frontend/ — React Dashboard

---

## 🚀 Quick Start

### Smart Contracts
```bash
cd smart-contracts
npm install
npx hardhat compile
```

### Backend
```bash
cd backend
pip install fastapi uvicorn pydantic jwt
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

---

## 📜 License
MIT License
