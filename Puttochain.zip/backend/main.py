from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
from datetime import datetime, timedelta
from typing import List
import jwt

app = FastAPI(title="Buddhochain API")

SECRET_KEY = "puttochain-secret"
ALGORITHM = "HS256"

users_db = {}
journals = []

class User(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class JournalEntry(BaseModel):
    username: str
    entry: str
    karma: int
    timestamp: datetime = datetime.utcnow()

@app.post("/auth/register")
def register(user: User):
    if user.username in users_db:
        raise HTTPException(status_code=400, detail="User exists")
    users_db[user.username] = user.password
    return {"msg": "User registered"}

@app.post("/auth/login", response_model=Token)
def login(user: User):
    if users_db.get(user.username) != user.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = jwt.encode({"sub": user.username, "exp": datetime.utcnow() + timedelta(hours=2)}, SECRET_KEY, algorithm=ALGORITHM)
    return {"access_token": token}

@app.post("/journals")
def add_journal(entry: JournalEntry):
    journals.append(entry.dict())
    return {"msg": "Journal added", "karma": entry.karma}

@app.get("/journals/{username}")
def get_journals(username: str):
    return [j for j in journals if j["username"] == username]

@app.get("/karma/{username}")
def get_karma(username: str):
    return sum(j["karma"] for j in journals if j["username"] == username)
